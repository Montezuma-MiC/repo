import xbmcaddon

MainBase = 'http://pastebin.com/raw/smam7ZkV'
addon = xbmcaddon.Addon('plugin.video.mic')